//>>built
define("dijit/form/nls/pt-pt/Textarea",({iframeEditTitle:"área de edição",iframeFocusTitle:"painel da área de edição"}));

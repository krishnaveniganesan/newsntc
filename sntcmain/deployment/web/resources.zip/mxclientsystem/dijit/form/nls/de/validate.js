//>>built
define("dijit/form/nls/de/validate",({invalidMessage:"Der eingegebene Wert ist ungültig. ",missingMessage:"Dieser Wert ist erforderlich.",rangeMessage:"Dieser Wert liegt außerhalb des gültigen Bereichs. "}));
